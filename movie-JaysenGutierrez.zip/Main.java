import java.util.*;
class Main{
 public static Scanner input=new Scanner(System.in);
 public static void main(String[]args){
  while(true){
   System.out.println("Would you like a quote from:");
   System.out.println("1-THEN I WILL POWER UP WITH THE STAR, AND DESTROY THE MUSHROOM KINGDOM!.");
   System.out.println("2-I'm the King of the World!");
   System.out.println("3-I'll Be Back.");
   int movie=input.nextInt();
   switch(movie){
    case 1:
      Bowser();
      break;
    case 2:
      Titanic();
      break;
    case 3:
      Terminator();
      break;
    default:
     System.out.println("This isn't a valid response. Try again.");
     input.next();
  }
 }
}
public static void Bowser(){
  System.out.println("THEN I WILL POWER UP WITH THE STAR, AND DESTROY THE MUSHROOM KINGDOM!.");
  input.nextLine();
  input.nextLine();
}
public static void Titanic(){
  System.out.println("I'm the King of the World!");
  input.nextLine();
  input.nextLine();
}
public static void Terminator(){
  System.out.println("I'll Be Back.");
  input.nextLine();
  input.nextLine();
}}